<?php

namespace App\Controller;

class Services{

    public function enMaj($text){
        return strtoupper($text);
    }

}